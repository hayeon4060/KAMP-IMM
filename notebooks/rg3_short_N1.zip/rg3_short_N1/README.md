# RG3 미성형 전용 모델 (N1) — 실행 패키지

## 모델
- **입력**: RG3 24개 변수(원값 21 + 추가 3: Switch_Over_Position, Average_Screw_RPM, Max_Back_Pressure)의 **직전 10샷 표준편차** → 정상 기준(unlabeled) 중앙값·IQR로 정규화, ±20 클리핑
- **학습**: labeled `미성형 = 1 / 정상 = 0` + **unlabeled 정상 3,000샷을 정상(가중치 0.3)으로 추가**
  - RandomForest 500트리, 깊이 4, leaf ≥ 3, class_weight = balanced_subsample
- **검증**: Run 하나씩 빼고 학습 → 뺀 Run 점수 (LORO), 시드 3개 평균
- **평가 제외**: 초기허용불량, RG3 R6(공식 2차 범위 밖) → 평가 591샷, 불량 25 (가스 17 · 미성형 8)

## 실행
```bash
pip install numpy pandas scikit-learn scipy
python rg3_short_n1.py          # 또는 rg3_short_N1.ipynb
```
결과: `outputs/rg3_short_n1/curve.csv`(검사 비율별), `rank.csv`(AP·ROC-AUC). 실행 1~2분

## 결과 (샷 단위, 시드 3개 평균)
| 검사 비율 | 검사 샷 | 미성형 (/8) | 불량 전체 (/25) | Precision | Recall | F1 |
|---|---|---|---|---|---|---|
| 5% | 30 | 2.0 | 4.7 | 0.156 | 0.187 | 0.170 |
| 10% | 60 | 3.0 | 7.0 | 0.117 | 0.280 | 0.165 |
| 15% | 89 | 3.0 | 10.7 | 0.120 | 0.427 | 0.187 |
| 20% | 119 | 3.7 (3~4) | 11.7 | 0.098 | 0.467 | 0.162 |

- AP_미성형(가스 샷 제외, 미성형 vs 정상) 0.092 (무작위 0.014), ROC-AUC_미성형 0.644
- 참고: 최종 통합 모델(가스 RF 시간 순 + N1, 68:32)에서는 검사 10%에 미성형 4/8 (가스 RF 목록이 미성형 일부를 같이 잡음)
- 해석: 우연보다는 높지만 미성형 8개 중 3개 수준 → RG3 미성형(계량지연형)은 현재 공정 변수로 한계

## 파일
| 파일 | 역할 |
|---|---|
| rg3_short_n1.py | 실행·평가 (이 파일만 실행) |
| semi_normal.py | N1 학습 (`fold_predict` 'N1_normal_augment', `loro`, `load_std`) |
| semi_sup.py | 데이터 불러오기·24개 변수 만들기 (`load`) |
| final_model.py | 공통 설정 (평가 제외 Run, 유형 묶기, 원값 목록) |
| inspect_curve.py / op_metrics.py | 검사 비율별 지표 |
| base/rg3_shots.csv | labeled 샷 (Run·사유) |
| linked/linked_labeled.csv | 공식 2차 라벨 ↔ 1차 공정값 연결 (추가 변수 3개) |
| linked/linked_unlabeled_rg3.csv | 1차 unlabeled (추가 변수 3개 · 날짜) |
| outputs/final_model/rg3_scores.csv | labeled 샷 + 평가 표시 (20b 결과) |
| outputs/final_model/rg3_train_features.csv | 정상 기준 데이터 (20a 결과) |

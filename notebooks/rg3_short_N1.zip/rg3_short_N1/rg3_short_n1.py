"""
rg3_short_n1.py — RG3 미성형 전용 모델 (N1) 단독 실행 · 평가

모델 N1 (41번 semi_normal 'N1_normal_augment')
  입력  : RG3 24개 변수(원값 21 + 추가 3: Switch_Over_Position, Average_Screw_RPM, Max_Back_Pressure)의 직전 10샷 표준편차
          → 정상 기준(unlabeled) 중앙값·IQR로 robust z, ±20 클리핑
  학습  : labeled 샷 '미성형 = 1 / 정상 = 0' + unlabeled 정상 기준 3,000샷을 '정상'으로 추가(가중치 0.3)
          RandomForest 500트리, 깊이 4, leaf ≥ 3, class_weight = balanced_subsample
  검증  : Run 하나씩 빼고 학습 → 뺀 Run 점수 (LORO), 시드 3개
  제외  : 초기허용불량, RG3 R6 (공식 2차 범위 밖) → 평가 불량 25샷 = 가스 17 + 미성형 8

평가 (샷 단위, 검사 5·10·15·20%)
  - 미성형 몇 개 중 몇 개 (주 지표), 불량 전체 몇 개 중 몇 개, Precision·Recall·F1
  - AP_미성형 (미성형 vs 정상만, 가스 샷 제외), ROC-AUC, R-Precision(불량 전체)

사용 (이 폴더에서)
  python rg3_short_n1.py            또는 노트북 rg3_short_N1.ipynb
필요 파일 (폴더 구조 그대로)
  base/rg3_shots.csv
  linked/linked_labeled.csv, linked/linked_unlabeled_rg3.csv
  outputs/final_model/rg3_scores.csv, outputs/final_model/rg3_train_features.csv
"""
import os
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score

import semi_normal as SN
import inspect_curve as IC

OUT = './outputs/rg3_short_n1'
RATES = (0.05, 0.10, 0.15, 0.20)


def short_metrics(lab, s):
    m = lab['eval'].values
    t = lab['type'].values[m]
    y = (lab['PassOrFail'].values[m] == 1).astype(int)
    v = np.asarray(s, float)[m]
    v = np.where(np.isfinite(v), v, np.nanmin(v[np.isfinite(v)]) - 1)
    mm = (t == '미성형') | (y == 0)
    ys = (t[mm] == '미성형').astype(int)
    return {'AP_미성형(가스 제외)': average_precision_score(ys, v[mm]), 'ROC-AUC_미성형': roc_auc_score(ys, v[mm]),
            '미성형 무작위 AP': ys.mean(), **{k: val for k, val in IC.rank_metrics(lab, s).items()
                                              if k in ('R-Precision', 'ROC-AUC', 'AP')}}


def run(seeds=(0, 1, 2), rates=RATES, verbose=True):
    os.makedirs(OUT, exist_ok=True)
    D = SN.load_std('rg3')
    lab = D['lab']
    if verbose:
        ev = lab['eval'].values
        print(f'RG3 평가 {int(ev.sum())}샷 | 불량 {lab.loc[ev, "type"].value_counts().to_dict()} | 입력 변수 {len(D["names"])}개')
    curves, ranks = [], []
    for sd in seeds:
        s = SN.loro(D, 'N1_normal_augment', '미성형', sd)
        curves.append(IC.curve(lab, s, rates, name='N1 (미성형 전용)').assign(seed=sd))
        ranks.append({'seed': sd, **short_metrics(lab, s)})
        if verbose:
            print(f'  seed {sd} 완료', flush=True)
    C = pd.concat(curves, ignore_index=True)
    for c in ('불량', '가스', '미성형'):
        C[c + ' 수'] = C[c].str.split('/').str[0].astype(int)
    tot = {c: C[c].iloc[0].split('/')[1] for c in ('불량', '가스', '미성형')}
    summ = C.groupby('검사 비율', sort=False).agg(
        검사_샷=('검사 샷', 'first'), 미성형=('미성형 수', 'mean'), 미성형_범위=('미성형 수', lambda x: f'{x.min()}~{x.max()}'),
        불량=('불량 수', 'mean'), 가스=('가스 수', 'mean'), Precision=('Precision', 'mean'), Recall=('Recall', 'mean'),
        F1=('F1', 'mean')).reset_index()
    summ = summ.rename(columns={'미성형': f'미성형(/{tot["미성형"]})', '불량': f'불량(/{tot["불량"]})', '가스': f'가스(/{tot["가스"]})'})
    summ['미성형 Recall'] = summ[f'미성형(/{tot["미성형"]})'] / int(tot['미성형'])
    R = pd.DataFrame(ranks)
    summ.to_csv(f'{OUT}/curve.csv', index=False, encoding='utf-8-sig')
    C.to_csv(f'{OUT}/curve_by_seed.csv', index=False, encoding='utf-8-sig')
    R.to_csv(f'{OUT}/rank.csv', index=False, encoding='utf-8-sig')
    return {'curve': summ, 'curve_by_seed': C, 'rank': R}


if __name__ == '__main__':
    pd.set_option('display.width', 200)
    res = run()
    print(res['curve'].round(3).to_string(index=False))
    print(res['rank'].mean(numeric_only=True).round(3).to_string())
